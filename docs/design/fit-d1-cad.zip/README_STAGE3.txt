TuneBox D1 — FIT PROTOTYPE ONLY

176 x 110 x 45 mm nominal enclosure.
Mounting, complete cable routing and physical/thermal/RF testing remain required.
The STEP contains our own case geometry and LABELLED REFERENCE ENVELOPES.
Vendor STEP files are not redistributed. No fabrication or CNC release is implied.
The STL is only the prototype core; actual veneer/finish and mounting follow.
See fit-d1.md in the repository and fit-d1-check.json for scope and assumptions.
